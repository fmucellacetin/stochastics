% Number of ghost-positions 
n = 1000;

% Load the transitionMatrix from a binary-file
load transitionMatrix.mat tM
k = length(tM);

% Starting position of the ghost
pos = randi(k,1);

% Result vector for the frequencies
frequency = zeros(1,k);
frequency(pos) = 1;

for i = 2:n  
  % Produce a random vector weighed with the given propabilites
  % at the momentary position
  % (for the given example "find"-command in MatLab also works)
  r = tM(pos,:).*rand(1,k);
  % Find the new position
  [a,pos] = max(r);
  % Update
  frequency(pos) = frequency(pos) + 1 ;
end;

% Bar-Plot of the result vector
bar(frequency);