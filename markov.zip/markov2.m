% Number of ghost-positions 
n = 1000;
% Number of differnt ghosts
m = 1000;

% Load the transitionMatrix from a binary-file
load transitionMatrix.mat tM
k = length(tM);
% Auxiliary vector for the histcounts-command
ind = 1:(k+1);

% Starting position of the m ghosts
pos = ceil(k*rand(m,1));

% Result vector for the frequencies
% histcounts counts the number of occurrences in first input vector
frequency = histcounts(pos,ind);
for i = 2:n  
  % Produce a random matrix weighed with the given propabilites
  % at the momentary positions of the ghosts  
  r = tM(pos,:).*rand(m,k);
  % Find the new positions
  [a,pos] = max(r,[],2);
  % Update of the result vector
  frequency = frequency + histcounts(pos,ind);
end;

% Bar-Plot of the result vector
bar(frequency);