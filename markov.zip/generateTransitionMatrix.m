neighbours=[42, 8531, 62, 751, 8642, 953, 84, 9752, 86]; 
k = length(neighbours);
tM = zeros(k);
adjacentNumber = ceil(log(neighbours)/log(10));

for i=1:k
    r = neighbours(i);
    a = adjacentNumber(i);
    for l = 1:a
        tM(i,rem(r,10)) = 1/a;
        r = (r - rem(r,10))/10;
    end
end

save transitionMatrix.mat tM