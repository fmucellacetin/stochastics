% Step A: Define the transition matrix tM
tM = [0 0.5 0 0.5 0 0 0 0 0;      % Transition probabilities from state 1
      0.25 0 0.25 0 0.25 0 0 0.25 0; % Transition probabilities from state 2
      0 0.5 0 0 0 0.5 0 0 0;        % Transition probabilities from state 3
      0.33 0 0 0 0.33 0 0.33 0 0;   % Transition probabilities from state 4
      0 0.25 0 0.25 0 0.25 0 0.25 0; % Transition probabilities from state 5
      0 0 0.33 0 0.33 0 0 0 0.33;   % Transition probabilities from state 6
      0 0 0 0.5 0 0 0 0.5 0;        % Transition probabilities from state 7
      0 0.25 0 0 0.25 0 0.25 0 0.25; % Transition probabilities from state 8
      0 0 0 0 0 0.5 0 0.5 0];       % Transition probabilities from state 9

% Step B: Initialize the frequency vector with zeros
frequency = zeros(1, 9);

% Step C: Choose a random starting vertex
current_vertex = randi(9);

% Step D: Perform the loop
num_iterations = 10000; % Adjust the number of iterations as needed
for i = 1:num_iterations
    % Step D.a: Update the frequency vector
    frequency(current_vertex) = frequency(current_vertex) + 1;
    
    % Step D.b: Move to an adjacent vertex based on transition probabilities
    probabilities = tM(current_vertex, :);
    next_vertex = randsample(9, 1, true, probabilities);
    
    % Update the current vertex
    current_vertex = next_vertex;
end

% Step E: Plot the frequencies
bar(frequency);
xlabel('Vertex');
ylabel('Frequency');
title('Frequency of Visits to Each Vertex');
